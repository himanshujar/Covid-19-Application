export class User {
    email: string;
    username: string;
    password: string;
    oldpassword: string;
    newpassword: string;
  }