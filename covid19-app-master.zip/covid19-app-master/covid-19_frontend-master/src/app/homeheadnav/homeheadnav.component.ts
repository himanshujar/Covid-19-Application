import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homeheadnav',
  templateUrl: './homeheadnav.component.html',
  styleUrls: ['./homeheadnav.component.css']
})
export class HomeheadnavComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
