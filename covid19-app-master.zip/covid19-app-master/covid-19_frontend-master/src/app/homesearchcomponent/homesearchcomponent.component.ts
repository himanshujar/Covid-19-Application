import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homesearchcomponent',
  templateUrl: './homesearchcomponent.component.html',
  styleUrls: ['./homesearchcomponent.component.css']
})
export class HomesearchcomponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
