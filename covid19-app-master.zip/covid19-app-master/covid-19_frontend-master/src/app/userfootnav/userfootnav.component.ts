import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userfootnav',
  templateUrl: './userfootnav.component.html',
  styleUrls: ['./userfootnav.component.css']
})
export class UserfootnavComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
